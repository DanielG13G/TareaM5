/*

Se necesita:

Escribir una Superclase llamada Formas y 4 subclases según el diagrama.
Crear las herencias necesarias para las subclases
Escribir los métodos en la clase padre los métodos en cada subclase (El recuadro con el texto en negrita representa los métodos).
Explicar el funcionamiento y estructura de todo su código en un documento de 2 páginas (Documentación de código).


. Escribir código propio, se valora más el esfuerzo que tengan código copiado de otros compañeros. 

2. Hacer todas las preguntas necesarias en el Foro Consulta al catedrático para el Parcial 2

3. Subir el proyecto en Netbeans en un solo archivo .rar o .zip.

4. Hacer un video de mínimo 1 minuto y máximo 3 minutos explicando su funcionamiento.


*/

public class Main {
    public static void main(String[] args) {
        Circulo circulo = new Circulo("Rojo", 5.0);
        circulo.dibujar();
        System.out.println("Área del círculo: " + circulo.calcularArea());

        Triangulo triangulo = new Triangulo("Azul", 3.0, 4.0, 5.0);
        triangulo.dibujar();
        System.out.println("Área del triángulo: " + triangulo.calcularArea());

        Cuadrado cuadrado = new Cuadrado("Verde", 6.0);
        cuadrado.dibujar();
        System.out.println("Área del cuadrado: " + cuadrado.calcularArea());

        Angulo angulo = new Angulo("Amarillo", 45.0);
        angulo.dibujar();
    }
}

class Forma {
    private String color;

    public Forma(String color) {
        this.color = color;
    }

    public void dibujar() {
        System.out.println("Dibujando una forma");
    }

    public void establecerColor(String nuevoColor) {
        this.color = nuevoColor;
    }
}

// Clase Círculo
class Circulo {
    private Forma forma;
    private double radio;

    public Circulo(String color, double radio) {
        this.forma = new Forma(color);
        this.radio = radio;
    }

    public void dibujar() {
        forma.dibujar();
        System.out.println("Dibujando un círculo");
    }

    // Método para calcular el área del círculo 
    public double calcularArea() {
        return Math.PI * radio * radio;
    }
}


class Triangulo {
    private Forma forma;
    private double lado1;
    private double lado2;
    private double lado3;

    public Triangulo(String color, double lado1, double lado2, double lado3) {
        this.forma = new Forma(color);
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.lado3 = lado3;
    }

    public void dibujar() {
        forma.dibujar();
        System.out.println("Dibujando un triángulo");
    }

    // Método para calcular el área del triángulo 
    public double calcularArea() {

        double s = (lado1 + lado2 + lado3) / 2;
        return Math.sqrt(s * (s - lado1) * (s - lado2) * (s - lado3));
    }
}

class Cuadrado {
    private Forma forma;
    private double lado;

    public Cuadrado(String color, double lado) {
        this.forma = new Forma(color);
        this.lado = lado;
    }

    public void dibujar() {
        forma.dibujar();
        System.out.println("Dibujando un cuadrado");
    }

    // Método para calcular el área del cuadrado 
    public double calcularArea() {
        return lado * lado;
    }
}

class Angulo {
    private Forma forma;
    private double medida;

    public Angulo(String color, double medida) {
        this.forma = new Forma(color);
        this.medida = medida;
    }

    public void dibujar() {
        forma.dibujar();
        System.out.println("Dibujando un ángulo");
    }
}